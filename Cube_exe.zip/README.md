# Cube_V2
A 3D Unity game that lets you manipulate a 2x2 Rubik's Cube and time yourself for completion 
release 1.d4
